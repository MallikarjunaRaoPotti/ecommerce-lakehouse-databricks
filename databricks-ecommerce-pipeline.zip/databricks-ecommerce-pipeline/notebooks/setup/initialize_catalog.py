# Databricks catalog initialization
