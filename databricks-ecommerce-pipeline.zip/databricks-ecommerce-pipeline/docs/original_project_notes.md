# 🛒 E-Commerce Data Pipeline — Medallion Architecture on Databricks

A production-style data engineering pipeline built on **Databricks** and **Apache Spark**, implementing the **Medallion Architecture** (Bronze → Silver → Gold) for an e-commerce platform — including revenue forecasting using **Facebook Prophet**.

---

## 🏗️ Architecture Overview

```
Raw CSV Files (Cloud Storage)
        │
        ▼
  ┌─────────────┐
  │   BRONZE    │  Raw ingestion with schema enforcement + metadata
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │   SILVER    │  Data cleaning, deduplication, type casting
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │    GOLD     │  Denormalized fact tables + business-ready views
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │ FORECASTING │  Revenue forecasting with Facebook Prophet
  └─────────────┘
```

---

## 🛠️ Tech Stack

| Tool | Purpose |
|---|---|
| **Databricks** | Notebook orchestration and Spark runtime |
| **Apache Spark / PySpark** | Distributed data processing |
| **Delta Lake** | ACID transactions, schema evolution, time travel |
| **Unity Catalog** | Data governance (catalog: `ecommerce`) |
| **Facebook Prophet** | Time-series revenue forecasting |
| **SQL** | Schema setup and analytical queries |
| **Python** | Transformations, anomaly handling, data quality |

---

## 📁 Project Structure

```
project_ecommerce/
│
├── 1_setup/
│   └── setup.py                        # Create catalog + schemas (bronze, silver, gold)
│
├── 1_medallion_processing_dim/
│   ├── 1_dim_bronze.py                 # Ingest dimension CSVs into Bronze Delta tables
│   ├── 2_dim_silver.py                 # Clean + transform dimension data
│   └── 3_dim_gold.py                   # Build final dimension tables
│
├── 3_medallion_processing_fact/
│   ├── 1_fact_bronze.py                # Ingest order_items fact data into Bronze
│   ├── 2_fact_silver.py                # Clean + cast + validate fact data
│   └── 3_fact_gold.py                  # Denormalized gold fact table (transactions)
│
└── Forecasting/
    └── forecasting.py                  # Monthly revenue forecast using Prophet
```

---

## 📊 Data Model

### Dimension Tables (Silver → Gold)
- `dim_brands` — Brand codes, names, category mapping
- `dim_category` — Product categories (deduplicated)

### Fact Tables (Silver → Gold)
- `fact_order_items` — Orders with customer, product, quantity, price, discount, tax, channel, coupon data
- `fact_transactions_denorm` — Gold layer denormalized view joining facts + dimensions

### Forecasting Output
- `gold.revenue_forecast` — 6-month forward revenue predictions (monthly)

---

## ⚙️ Key Features

- **Schema enforcement** on raw CSV ingestion using `StructType`
- **Metadata columns** — `_source_file`, `ingested_at`, `ingest_timestamp` tracked on every record
- **Data quality** — deduplication, null handling, regex-based string cleaning, anomaly correction
- **Delta Lake writes** with `mergeSchema=true` for safe schema evolution
- **Forecasting** — Aggregates monthly revenue from Gold layer → trains Prophet model → writes 6-month forecast back to Delta

---

## 🚀 How to Run

1. Import notebooks into your Databricks workspace
2. Run `1_setup/setup.py` to create the `ecommerce` catalog and schemas
3. Upload raw CSV files to `/Volumes/ecommerce/source_data/raw/`
4. Run notebooks in order:
   - `1_dim_bronze.py` → `2_dim_silver.py` → `3_dim_gold.py`
   - `1_fact_bronze.py` → `2_fact_silver.py` → `3_fact_gold.py`
5. Run `forecasting.py` to generate revenue predictions

---

## 📈 Sample Output

| Month | Predicted Revenue (yhat) |
|---|---|
| 2025-07 | ₹4,21,500 |
| 2025-08 | ₹4,58,200 |
| 2025-09 | ₹4,83,700 |

*(Values are illustrative — actual output depends on your data)*

---

## 👤 Author

**Mallikarjunarao**
- 📧 [your email]
- 💼 [LinkedIn URL]
- 🐙 [GitHub URL]
