
def test_net_amount_column_exists(df):
    assert "net_amount" in df.columns
