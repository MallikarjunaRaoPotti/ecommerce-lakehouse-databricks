
# Databricks E-Commerce Pipeline

A Final Year Major Project focused on building a scalable e-commerce analytics pipeline using Databricks, Apache Spark, Delta Lake, and Medallion Architecture.

---

## Project Overview

This project demonstrates an end-to-end modern data engineering workflow using Databricks Lakehouse concepts.

The pipeline processes raw e-commerce transaction data through:
- Bronze Layer (Raw Ingestion)
- Silver Layer (Data Cleaning & Transformation)
- Gold Layer (Business Analytics)

The project also includes:
- Revenue forecasting using Facebook Prophet
- Interactive Databricks dashboard
- Business analytics reporting
- SQL-based insights

---

## Tech Stack

- Databricks
- Apache Spark
- PySpark
- Delta Lake
- SQL
- Python
- Unity Catalog
- Facebook Prophet

---

## Architecture

### Medallion Architecture
- Bronze → Raw ingestion
- Silver → Cleaned and validated data
- Gold → Analytics-ready datasets

### Features
- Schema enforcement
- Data quality validation
- Delta Lake storage
- Revenue forecasting
- Interactive dashboards

---

## Dashboard Highlights

- Monthly Revenue Trends
- Currency-wise Transactions
- Customer Distribution
- Heatmap Analytics
- Revenue Forecasting

---

## Recruiter-Focused Highlights

- Built scalable ETL pipelines using PySpark
- Implemented Medallion Architecture in Databricks
- Designed analytical dashboards using Databricks SQL
- Performed business-focused revenue forecasting
- Applied Delta Lake concepts for reliable storage
- Organized project using production-style folder structure

---

## Author

### Mallikarjuna Rao Potti

- LinkedIn: https://www.linkedin.com/in/mallikarjuna7
- GitHub: https://github.com/MallikarjunaRaoPotti
